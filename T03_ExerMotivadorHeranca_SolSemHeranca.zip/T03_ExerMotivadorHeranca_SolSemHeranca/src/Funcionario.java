public class Funcionario{
    public static final double LIM_ISENCAO_IR = 2000;
    private String matricula; 
    private String nome;
    private double salarioBruto;
    private CatRisco catRisco;
    private int catPesq;
    
    // Funcionario sem categoria de risco e que não é pesquisador
    public Funcionario(String matricula, String nome, double salarioBruto){
        this.matricula = matricula;
        this.nome = nome;
        this. salarioBruto = salarioBruto;
        this.catRisco = CatRisco.SemRisco;
        this.catPesq = 0;
    }

    // Funcionario não pesquisador com categoria de risco
    public Funcionario(String matricula, String nome, double salarioBruto,CatRisco catRisco){
        this.matricula = matricula;
        this.nome = nome;
        this. salarioBruto = salarioBruto;
        this.catRisco = catRisco;
        this.catPesq = 0;
    }

    // Pesquisador sem categoria de risco
    public Funcionario(String matricula, String nome, double salarioBruto,int catPesq){
        this.matricula = matricula;
        this.nome = nome;
        this. salarioBruto = salarioBruto;
        this.catRisco = CatRisco.SemRisco;
        this.catPesq = catPesq;
    }

    // Pesquisador com categoria de risco
    public Funcionario(String matricula, String nome, double salarioBruto,CatRisco catRisco,int catPesq){
        this.matricula = matricula;
        this.nome = nome;
        this. salarioBruto = salarioBruto;
        this.catRisco = catRisco;
        this.catPesq = catPesq;
    }

	public String getMatricula() {
		return matricula;
	}
	
	public String getNome() {
		return nome;
	}
	
    public CatRisco getCatRisco(){
        return catRisco;
    }

    public int getCatPesq(){
        return catPesq;
    }

	public double getSalarioBruto() {
		return salarioBruto;
	}
    
    public double getINSS(){
        return salarioBruto*0.1;
    }

    public double getAdicionalRisco(){
        if (catRisco == CatRisco.SemRisco){
            return 0.0;
        }else{
            return salarioBruto * 0.25;
        }
    }

    public double getAdicionalPesquisador(){
        switch(this.catPesq){
            case 1: return getSalarioBruto() * 0.05;
            case 2: return getSalarioBruto() * 0.1;
            case 3: return getSalarioBruto() * 0.2;
            default: return 0;
        }
    }

    public double getImpRenda(){
        if (salarioBruto <= LIM_ISENCAO_IR){
            return 0.0;
        }else{
            double aux = salarioBruto - LIM_ISENCAO_IR;
            double ir = aux * 0.2;
            return ir;
        }
    }

    public double getSalarioLiquido(){
        double salarioLiquido = salarioBruto + getAdicionalRisco() + getAdicionalPesquisador() - getINSS() - getImpRenda();
        return salarioLiquido;
    }

    public String toString() {
        String aux = "";
        aux += "Categoria: "+this.getClass().getName()+"\n";
        aux += "Matricula: "+this.getMatricula()+"\n";
        aux += "Nome: "+this.getNome()+"\n";
        aux += "Salario bruto: "+this.getSalarioBruto()+"\n";
        aux += "(-) INSS: "+this.getINSS()+"\n";
        aux += "(-) IR: "+this.getImpRenda()+"\n";
        if (catRisco != CatRisco.SemRisco){
            aux+= "(+) Adic.Risco: "+this.getAdicionalRisco()+"\n";
        }
        if (catPesq != 0){
            aux+= "(+) Adic.Pesquisador: "+this.getAdicionalPesquisador()+"\n";
        }
        aux += "Salario liquido: "+this.getSalarioLiquido()+"\n";
        aux += "----------";
        return aux;    
    }
}