import java.util.ArrayList;

public class CadastroFuncionarios{
    private ArrayList<Funcionario> funcionarios;

    private void carregaFuncionarios(){
        funcionarios.add(new Funcionario("A3212","Huguinho Pato",1890.0));
        funcionarios.add(new Funcionario("A3312","Zezinho Pato",3720.0));
        funcionarios.add(new Funcionario("A3412","Luizinho Pato",8940.0));
        funcionarios.add(new Funcionario("B9931","Lala Pata",4220.0));
        funcionarios.add(new Funcionario("B9932","Lele Pata",1283.0));
        funcionarios.add(new Funcionario("B9933","Lili Pata",12438.0));
        funcionarios.add(new Funcionario("R001", "Huguinho",3420.0 ,CatRisco.Media));
        funcionarios.add(new Funcionario("R002", "Zezinho",5622.0 ,CatRisco.Baixa));
        funcionarios.add(new Funcionario("R003", "Luizinho",8931.0 ,CatRisco.Alta));
        funcionarios.add(new Funcionario("P001", "Lala",3420.0 ,1));
        funcionarios.add(new Funcionario("P002", "Lele",5622.0 ,2));
        funcionarios.add(new Funcionario("P003", "Lili",8931.0 ,3));
        funcionarios.add(new Funcionario("PR01", "Mickey",10301.0 ,CatRisco.Alta,3));
    }

    public CadastroFuncionarios(){
        funcionarios = new ArrayList<>();
        carregaFuncionarios();
    }

    public void cadastraFuncionario(Funcionario funcionario){
        funcionarios.add(funcionario);
    }

    public Funcionario recuperaPorMatricula(String matricula){
        for(Funcionario func:funcionarios){
            if (func.getMatricula().equals(matricula)){
                return func;
            }
        }
        return null;
    }
}