public enum CatRisco{
    SemRisco,Baixa, Media, Alta
}