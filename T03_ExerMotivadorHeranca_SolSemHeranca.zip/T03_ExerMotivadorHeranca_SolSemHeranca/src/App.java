public class App{
    public static void main(String args[]){
        TerminalConsulta tc = new TerminalConsulta();
        tc.menu();

        //new TerminalConsulta().menu();
    }
}